package com.example.mykeke

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
